<template>
    <span class="text-white">Page not found</span>
</template>
  
<script>
export default {
    name: "CatchAllPage"
}
</script>
  