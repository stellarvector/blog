import Particles from "particles.vue";

Vue.use(Particles);