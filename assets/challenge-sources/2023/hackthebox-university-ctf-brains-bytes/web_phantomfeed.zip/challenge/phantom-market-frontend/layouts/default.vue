<template>
    <div>
        <main>
            <Nuxt />
        </main>
    </div>
</template>